#pragma once

#include <any>
#include <memory>    // unique_ptr
#include <stdexcept> // runtime_error
#include <string>
#include <vector>

namespace Domain::Facility
{
	class FacilityHandler
	{
	public:
		struct FacilityException : std::runtime_error
		{
			using runtime_error::runtime_error;
		};
		struct BadCommand : FacilityException
		{
			using FacilityException::FacilityException;
		};

		static std::unique_ptr<FacilityHandler> createFacility();



		///virtual functions

		virtual ~FacilityHandler() noexcept = 0;


	private:
	protected:
		// Copy assignment operators, protected to prevent mix derived-type assignments
		FacilityHandler& operator=(const FacilityHandler& rhs) = default; // copy assignment
		FacilityHandler& operator=(FacilityHandler&& rhs) = default;      // move assignment
	};

} // namespace Domain::Item
