#pragma once

#include <string>
#include <any>
#include <vector>

#include "Domain/Room/checkout.hpp"


namespace Domain::Room
{
	
	Checkout::Checkout() {


	}

	std::string Checkout::checkoutroom(std::string roomnum)
	{
		auto checkedout = obj.makeroomavailable(roomnum);

		return checkedout;
	}
	
	Checkout::~Checkout() {}

}// namespace Domain::Room
