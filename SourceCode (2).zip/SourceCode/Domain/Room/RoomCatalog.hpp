#pragma once
#include <iostream>
#include <vector>
#include "Domain/Room/Room.hpp"
//#include "Domain/Room/RoomSpecification.hpp"
#include "Domain/Room/RoomHandler.hpp"


namespace Domain::Room
{
	class RoomCatalog
	{
	public:

		//test
		void printall();

		RoomCatalog();

		
		std::string avialableRoomlist(std::string date, std::string guestnum, std::string nights);

		//normal fucntions
		std::string makeroomunavaialbe(std::string roomnum,std::string user) ;

		std::string makeroomavailable(std::string roomnum);
		~RoomCatalog();

	private:
		
		/** 120 = king     121 = king      122 = queen     123 = queen
	** 124 = king     125 = queen     126 = 2 king    127 = 2 king
	** 128 = suite    129 = suite     130 = suite
	*/
		int row = 11;
		int col = 8;
		std::string roomList[11][8] = {
								// roomnumber|type| checkin | checkout | availability | price | occupancy |description
								{ "120", "king","n/a", "n/a", "Available","129.99","2","standard"},
								{ "121", "king", "n/a", "n/a", "Available","129.99","2","standard"},
								{ "122", "Queen", "n/a", "n/a", "Available", "109.99", "2", "standard" },
								{ "123", "Queen", "n/a", "n/a", "Available", "109.99", "2", "standard" },
								{ "124", "king", "n/a", "n/a", "Available", "129.99","2","standard" },
								{ "125", "Queen", "n/a", "n/a", "Available", "109.99", "2", "standard" },
								{ "126", "doubleking", "n/a", "n/a", "Available", "149.99", "2", "Two Kings - standard" },
								{ "127", "doubleking", "n/a", "n/a", "Available", "149.99", "2", "Two Kings - standard" },
								{ "128", "suite", "n/a", "n/a", "Available", "169.99", "2", "VIP" },
								{ "129", "suite", "n/a", "n/a", "Available",  "169.99", "2", "VIP"  },
								{ "130", "suite", "n/a", "n/a", "Available",  "169.99", "2", "VIP"  }
							
									};
	};
}// namespace Domain::Room
