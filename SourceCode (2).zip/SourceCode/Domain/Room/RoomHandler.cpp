

#include <algorithm>    // std::any_of()
#include <memory>       // unique_ptr, make_unique<>()
#include <stdexcept>    // logic_error
#include <string>
#include "Domain/Room/RoomHandler.hpp"
#include "Domain/Room/RoomCatalog.hpp"
#include "Domain/Room/RoomReservation.hpp"
#include "Domain/Room/checkout.hpp"

namespace Domain::Room
{
	RoomHandler::~RoomHandler() noexcept = default;

	// returns a specialized object specific to the specified role
	std::unique_ptr<RoomHandler> RoomHandler::createRoom(const std::string request)
	{
		
		
				if (request == "askavailableRoom")    return std::make_unique<Domain::Room::RoomReservation>();
				if (request == "roomReservation")     return std::make_unique < Domain::Room::RoomReservation>();
				if (request == "unassignroom")			return std::make_unique <Domain::Room::Checkout>();
				
			//	if (request == "reserveRoom") return std::make_unique<Domain::Room::>(credentials);

				throw std::logic_error("Invalid role requested in function " + std::string(__func__)); // Oops, should never get here but ...  Throw something
			
		//}
		//catch (const TechnicalServices::Persistence::PersistenceHandler::NoSuchUser&) {}  // Catch and ignore this anticipated condition

		//return nullptr;
	}
} // namespace Domain::Session
