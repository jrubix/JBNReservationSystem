#pragma once
#include <iostream>
#include <vector>
#include "Domain/Room/Room.hpp"
#include "Domain/Room/RoomCatalog.hpp"
#include "Domain/Room/RoomHandler.hpp"


namespace Domain::Room
{
	class Checkout : public RoomHandler
	{
	public:



		Checkout();

		//override functions
		std::string checkoutroom(std::string roomnum) override;


		//std::any makeroomunavaialbe(std::string roomnum, std::string user)override;
		~Checkout();

		//std::unique_ptr<Domain::Room::RoomCatalog> _catalogPtr;

	private:

		RoomCatalog obj;
	};
}// namespace Domain::Room
#pragma once
