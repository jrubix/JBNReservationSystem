#pragma once
#include <iostream>
#include <vector>
#include "Domain/Room/Room.hpp"
#include "Domain/Room/RoomCatalog.hpp"
#include "Domain/Room/RoomHandler.hpp"


namespace Domain::Room
{
	class RoomReservation : public RoomHandler
	{
	public:

		

		RoomReservation();

		//override functions
		std::string reserveroom(std::string roomnum,std::string user) override;
		std::any makeavialableRoomlist(std::string date, std::string guestnum, std::string nights) override; //for RoomCatalog


		//std::any makeroomunavaialbe(std::string roomnum, std::string user)override;
		~RoomReservation();

		//std::unique_ptr<Domain::Room::RoomCatalog> _catalogPtr;

	private:
	
		RoomCatalog obj;
	};
}// namespace Domain::Room
