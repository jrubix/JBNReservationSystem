#pragma once

#include <string>
#include <any>
#include <vector>
#include <iostream>
#include "Domain/Room/RoomCatalog.hpp"
//#include "Domain/Room/RoomSpecification.hpp"

namespace Domain::Room
{
	
	RoomCatalog::RoomCatalog() {
		

	}


	///makeavialableRoomlist...function implimentation
	std::string RoomCatalog::avialableRoomlist(std::string date, std::string guestnum, std::string nights)
	{
		
		std::string rinfo;
		//int vecsize = sizeof(roomList);
			for (int i = 0; i < row; i++)
			{
				if (roomList[i][4] == "Available") 
				{ 
					//std::cout << "the available room is :" << roomList[i][0] << std::endl; 
					rinfo += roomList[i][0] + "-" + roomList[i][1] + " " + roomList[i][4] + " Room for checking date \"" + date + "\" for \"" + nights + "\" night(s) and for \"" + guestnum + "\" hotel guest(s) at: $" + roomList[i][5] + "\n";;
				//	rinfo += " Room for checking date \"" + date + "\" for \"" + nights + "\" night(s) and for \"" + guestnum + "\" hotel guest(s) at: $" + roomList[i][5] + "\n";

				}
					//continue;
				  //direct access second vector, change if additional fields
				  //
			}
		return rinfo;
	}

	///make room unavaialbe
	std::string RoomCatalog::makeroomunavaialbe(std::string roomnum, std::string user)
	{
		//std::cout << "The given room number is: " << roomnum << std::endl;
		//int vecsize = sizeof(roomList);
	    std::string reservesuccess;
		reservesuccess = "That room was not found.\n";
		for (int i = 0; i < row; i++)
		{
			//std::cout << "The avaialbe room number is: " << roomList [0][0]<< std::endl;
			 if (roomList[i][0] == roomnum)
				 {
					if (roomList[i][4] == "Available")
						{
							roomList[i][4] = "Unavailable";
							reservesuccess = "Room " + roomList[i][0] + " - " + roomList[i][1] + "is reserved by " + user;
		  
						}
					else
						{
							 reservesuccess = "That room is unavailable.\n";
						}
				}
		}
	return reservesuccess;
	}

	//make room available
	std::string RoomCatalog::makeroomavailable(std::string roomnum)
	{
		std::string checkoutsuccess;
		checkoutsuccess = "Unsuccessful\n";
		for (int i = 0; i < row; i++)
		{
			if (roomList[i][0] == roomnum)
			{
				if (roomList[i][4] == "Available")
				{
					checkoutsuccess = "Room " + roomnum + " is not occupied. Request canceled.";
					return checkoutsuccess;
				}
				roomList[i][4] = "Available";
				
				checkoutsuccess = "Checking out room " + roomnum + "... Successful";
				return { checkoutsuccess };
			}
		}

	
		return checkoutsuccess;
	}
	RoomCatalog::~RoomCatalog() {}

}// namespace Domain::Room
