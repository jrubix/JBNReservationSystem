#pragma once

#include <string>
#include <any>
#include <vector>

#include "Domain/Room/RoomReservation.hpp"


namespace Domain::Room
{
	//test
	//void RoomCatalog::printall() {
	//	for (int i = 0; i < roomList.size() - 1; i++) {
	//		std::cout << roomList[i].getRoomNumber();
	//	}
	//}


	RoomReservation::RoomReservation(){
		
		
	}


	///makeavialableRoomlist...function implimentation
	std::string RoomReservation::reserveroom(std::string roomnum,std::string user)
	{
		/////*_catalogPtr = std::make_unique<Domain::Room::RoomCatalog>();

		////auto reserved = _catalogPtr->makeroomunavaialbe(roomnum,user);*/
		/////*std::unique_ptr<Domain::Room::RoomCatalog> pointer;
		////pointer = std::make_unique<Domain::Room::RoomCatalog>();*/
		////std::unique_ptr<Domain::Room::RoomHandler> pointer;
		////pointer = Domain::Room::RoomHandler::createRoom("changeincatalog");
		
		auto reserved = obj.makeroomunavaialbe(roomnum, user);

		//return reserved;

		return reserved;
	}

	std::any RoomReservation::makeavialableRoomlist(std::string date, std::string guestnum, std::string nights)
	{
		//RoomCatalog obj;
		std::string result = obj.avialableRoomlist(date,guestnum,nights);
		return result;
	}
	RoomReservation::~RoomReservation() {}

}// namespace Domain::Room
