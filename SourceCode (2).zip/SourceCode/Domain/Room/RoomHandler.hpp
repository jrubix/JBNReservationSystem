#pragma once

#include <any>
#include <memory>      // unique_ptr
#include <stdexcept>   // runtime_error
#include <string>
#include <vector>

//#include "TechnicalServices/Persistence/PersistenceHandler.hpp"

namespace Domain::Room
{
	
	class RoomHandler
	{
	public:
		// Exceptions
		struct RoomException : std::runtime_error { using runtime_error::runtime_error; };
		struct   BadCommand : RoomException { using RoomException::RoomException; };

		//virtual functions
		virtual std::any makeavialableRoomlist(std::string date, std::string guestnum, std::string nights) = 0; //for RoomCatalog
		virtual std::string reserveroom(std::string roomnum,std::string user) = 0;
	   
		virtual std::string checkoutroom(std::string roomnum) =0;

		//static pointer makes
		static std::unique_ptr<RoomHandler> createRoom(const std::string requestmessage);

		
		// Destructor
		// Pure virtual destructor helps force the class to be abstract, but must still be implemented
		virtual ~RoomHandler() noexcept = 0;

	protected:
		// Copy assignment operators, protected to prevent mix derived-type assignments
		RoomHandler& operator=(const RoomHandler& rhs) = default;  // copy assignment
		RoomHandler& operator=(RoomHandler&& rhs) = default;  // move assignment

	};    // class SessionHandler
} // namespace Domain::Session
