#include "Domain/Hotel/Hotel.hpp"
#include "Domain/Hotel/HotelHandler.hpp"
#include <iostream>
using namespace std;
namespace Domain::Hotel
{
  HotelHandler::~HotelHandler() noexcept = default;
  std::unique_ptr<HotelHandler> HotelHandler::createHotel()
  {
	
	  std::cout << "This is creating Hotel pointer" << endl;
    return std::make_unique<Domain::Hotel::HotelBase>();
  }
} // namespace Domain::Hotel
