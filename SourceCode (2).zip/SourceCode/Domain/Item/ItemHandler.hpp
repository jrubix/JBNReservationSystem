#pragma once

#include <any>
#include <memory>    // unique_ptr
#include <stdexcept> // runtime_error
#include <string>
#include <vector>

namespace Domain::Item
{
	class ItemHandler
	{
	public:
		struct ItemException : std::runtime_error
		{
			using runtime_error::runtime_error;
		};
		struct BadCommand : ItemException
		{
			using ItemException::ItemException;
		};

		static std::unique_ptr<ItemHandler> createItem();


		
	///virtual functions

		virtual ~ItemHandler() noexcept = 0;


	private:
	protected:
		// Copy assignment operators, protected to prevent mix derived-type assignments
		ItemHandler& operator=(const ItemHandler& rhs) = default; // copy assignment
		ItemHandler& operator=(ItemHandler&& rhs) = default;      // move assignment
	};

} // namespace Domain::Item
